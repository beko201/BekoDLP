"""Versioned application preferences with validation and atomic persistence."""
import json
import math
import os
from pathlib import Path
import shutil
import tempfile
import time
from copy import deepcopy
from media_options import OUTPUT_DEFAULTS, AUDIO_BIT_DEPTHS, AUDIO_BITRATES, VIDEO_CODECS, AUDIO_CODECS, CONTAINERS, validate_output_options

SCHEMA_VERSION = 1
MAX_WORKERS = 16
MAX_VIDEO_WORKERS = 4
MAX_FFMPEG_THREADS = 64
MAX_FRAGMENT_DOWNLOADS = 4
MAX_NETWORK_CONNECTIONS = 32
MAX_SETTINGS_BYTES = 1024 * 1024
QUALITIES = ("144p", "240p", "360p", "480p", "720p", "1080p", "1440p(2K)", "2160p(4K)")
BITRATES = ("128k", "192k", "256k", "320k")
CODECS = ("Original (Automatic)", "H.264 (Compatibility)")
# Accept historical labels so existing preferences retain their codec selection.
_LEGACY_CODECS = {"Orijinal (Otomatik)": CODECS[0], "H.264 (Uyumluluk)": CODECS[1]}
DEFAULTS = dict(schema_version=SCHEMA_VERSION, language='en', last_folder="", workers=3,
                video_workers=1, ffmpeg_threads=0,
                fragment_downloads=1, network_connections=8,
                mp3_bitrate="192k", format="MP4", quality="1080p",
                codec_mode=CODECS[0], log_max_bytes=5 * 1024 * 1024,
                log_backup_count=3, log_repeat_seconds=60)
DEFAULTS.update(OUTPUT_DEFAULTS)


class UnsupportedSettingsVersion(ValueError):
    pass


class SettingsFileTooLarge(ValueError):
    pass


def validate_settings(data):
    if not isinstance(data, dict):
        raise ValueError("The settings file root must be a JSON object.")
    version = data.get("schema_version", SCHEMA_VERSION)
    if type(version) is not int or version != SCHEMA_VERSION:
        raise UnsupportedSettingsVersion(f"Unsupported settings version: {version!r}")
    try:
        result = deepcopy(data)  # Preserve unknown fields without sharing nested mutable values.
    except RecursionError as error:
        raise ValueError('The settings data has excessive nesting.') from error
    if "output_mode" not in data:
        # Migrate older saved MP3/H.264 choices, without rewriting the file at load time.
        if data.get("format") == "MP3":
            result.update(output_mode="audio", container="mp3", audio_codec="mp3")
        elif isinstance(data.get("codec_mode"), str) and _LEGACY_CODECS.get(data.get("codec_mode"), data.get("codec_mode")) == CODECS[1]:
            result.update(output_mode="video", container="mp4", video_codec="h264", audio_codec="aac")
    # Removed UI choices retain their nearest compatible profile on load.
    if result.get("output_mode") == "automatic":
        result["output_mode"] = "video"
    if result.get("container") == "aac":
        result["container"] = "m4a"
    elif result.get("container") == "ogg":
        audio_codec = result.get('audio_codec')
        result["container"] = {"opus": "opus", "flac": "flac"}.get(audio_codec, "auto") if isinstance(audio_codec, str) else 'auto'
    if result.get("audio_codec") in ("pcm_s16le", "pcm_s24le"):
        result.setdefault("audio_bit_depth", "16" if result["audio_codec"] == "pcm_s16le" else "24")
        result["audio_codec"] = "lpcm"
    issues = []
    choices = {"language": ('en', 'tr'), "format": ("MP4", "MP3"), "quality": QUALITIES,
               "mp3_bitrate": BITRATES, "codec_mode": CODECS,
               "output_mode": ("video", "audio"), "container": tuple(CONTAINERS),
               "video_codec": tuple(VIDEO_CODECS), "audio_codec": tuple(AUDIO_CODECS),
               "audio_bit_depth": AUDIO_BIT_DEPTHS, "audio_bitrate": AUDIO_BITRATES, "video_quality": ("high", "balanced", "small")}
    ranges = {"workers": (1, MAX_WORKERS), "video_workers": (1, MAX_VIDEO_WORKERS),
              "ffmpeg_threads": (0, MAX_FFMPEG_THREADS), "log_max_bytes": (64 * 1024, 100 * 1024 * 1024),
              "fragment_downloads": (1, MAX_FRAGMENT_DOWNLOADS), "network_connections": (2, MAX_NETWORK_CONNECTIONS),
              "log_backup_count": (1, 10), "log_repeat_seconds": (1, 3600)}
    for key, default in DEFAULTS.items():
        value = result.get(key, default)
        if key == "audio_bitrate" and key not in data:
            value = data.get("mp3_bitrate", default)
        if key == "codec_mode" and isinstance(value, str):
            value = _LEGACY_CODECS.get(value, value)
        valid = True
        if key in choices:
            valid = isinstance(value, str) and value in choices[key]
        elif key in ranges:
            low, high = ranges[key]
            valid = type(value) is int and low <= value <= high
        elif key == "last_folder":
            valid = isinstance(value, str) and "\x00" not in value
        if not valid:
            issues.append(key)
            value = default
        result[key] = value
    try:
        validate_output_options(result)
    except ValueError:
        issues.append("output profile")
        result.update(OUTPUT_DEFAULTS)
    return result, issues


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'Duplicate settings key: {key}')
        result[key] = value
    return result


def _reject_constant(value):
    raise ValueError(f'Non-finite JSON number is not allowed: {value}')


def _finite_float(value):
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f'Non-finite JSON number is not allowed: {value}')
    return number


def _read_document(path):
    with open(path, 'rb') as stream:
        content = stream.read(MAX_SETTINGS_BYTES + 1)
    if len(content) > MAX_SETTINGS_BYTES:
        raise SettingsFileTooLarge('The settings file exceeds the 1 MiB limit.')
    try:
        return json.loads(content.decode('utf-8-sig'), object_pairs_hook=_unique_object,
                          parse_constant=_reject_constant, parse_float=_finite_float)
    except RecursionError as error:
        raise ValueError('The settings file has excessive JSON nesting.') from error


def _read(path):
    return validate_settings(_read_document(path))


def _serialize(data):
    try:
        content = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    except (TypeError, ValueError, RecursionError) as error:
        raise ValueError('Settings must contain finite, serializable JSON values.') from error
    if len(content.encode('utf-8')) > MAX_SETTINGS_BYTES:
        raise SettingsFileTooLarge('The settings data exceeds the 1 MiB limit.')
    return content


def _atomic_write(path, data):
    path = Path(path)
    content = _serialize(data)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class SettingsStore:
    def __init__(self, path):
        self.path = Path(path)
        self.backup = Path(str(path) + ".bak")
        self.data = dict(DEFAULTS)
        self.writable = True

    def load(self):
        """Return preferences and user-facing recovery or validation warnings."""
        self.data = deepcopy(DEFAULTS)
        self.writable = True
        try:
            self.data, issues = _read(self.path)
        except FileNotFoundError:
            if not self.backup.exists():
                return deepcopy(self.data), []
            try:
                self.data, issues = _read(self.backup)
            except (OSError, ValueError):
                self.writable = False
                raise
            return deepcopy(self.data), ["The primary settings file is missing; the backup was loaded.", *issues]
        except (OSError, ValueError) as error:
            # Preserve files with unsupported schemas or read errors.
            if isinstance(error, (OSError, UnsupportedSettingsVersion, SettingsFileTooLarge)):
                self.writable = False
                raise
            preserved = Path(str(self.path) + f".corrupt-{time.time_ns()}")
            try:
                shutil.copy2(self.path, preserved)
            except OSError:
                self.writable = False
                raise
            try:
                self.data, issues = _read(self.backup)
            except FileNotFoundError:
                issues = []
            except (OSError, ValueError):
                self.writable = False
                raise error
            return deepcopy(self.data), [f"Could not read the settings file: {error}. Original: {preserved}. "
                                     "A valid backup or the default settings were loaded.", *issues]
        return deepcopy(self.data), (["Invalid preferences were reset to defaults: " + ", ".join(issues)] if issues else [])

    def save(self, changes):
        if not self.writable:
            return False
        data, issues = validate_settings({**self.data, **changes})
        if issues:
            raise ValueError("Invalid preferences: " + ", ".join(issues))
        try:
            previous_original = _read_document(self.path)
            previous, previous_issues = validate_settings(previous_original)
        except FileNotFoundError:
            previous = None
        except (UnsupportedSettingsVersion, SettingsFileTooLarge):
            self.writable = False
            raise
        except ValueError:
            # Preserve corruption that occurred after load() before replacing the file.
            shutil.copy2(self.path, str(self.path) + f".corrupt-{time.time_ns()}")
            previous = None
        if previous is not None:
            # Retain edits made on disk to fields this save did not change.
            data, issues = validate_settings({**previous, **changes})
            if issues:
                raise ValueError('Invalid preferences: ' + ', '.join(issues))
            if previous_original == data and not previous_issues:
                self.data = data
                return False
            _serialize(data)  # Reject unsafe updates before replacing either runtime file.
            if not previous_issues:
                _atomic_write(self.backup, previous)
        _atomic_write(self.path, data)
        self.data = data
        return True
